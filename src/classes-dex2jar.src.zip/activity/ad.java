package activity;

import android.support.v4.view.ViewPager.OnPageChangeListener;

final class ad
  implements ViewPager.OnPageChangeListener
{
  ad(ac paramac)
  {
  }

  public final void onPageScrollStateChanged(int paramInt)
  {
  }

  public final void onPageScrolled(int paramInt1, float paramFloat, int paramInt2)
  {
  }

  public final void onPageSelected(int paramInt)
  {
    ac.c(this.a, paramInt);
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     activity.ad
 * JD-Core Version:    0.6.2
 */