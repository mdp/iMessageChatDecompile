package activity;

import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import com.d.a;

final class bs
  implements CompoundButton.OnCheckedChangeListener
{
  bs(NotifyActivity paramNotifyActivity)
  {
  }

  public final void onCheckedChanged(CompoundButton paramCompoundButton, boolean paramBoolean)
  {
    this.a.h.d(paramBoolean);
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     activity.bs
 * JD-Core Version:    0.6.2
 */