package activity;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import com.a.d;
import com.d.a;

final class ar
  implements DialogInterface.OnClickListener
{
  ar(FriendListActivity paramFriendListActivity)
  {
  }

  public final void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    this.a.d.a(this.a.h.b());
    this.a.b();
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     activity.ar
 * JD-Core Version:    0.6.2
 */