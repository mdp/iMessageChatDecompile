package activity;

import android.support.v4.view.ViewPager.OnPageChangeListener;

final class az
  implements ViewPager.OnPageChangeListener
{
  az(ay paramay)
  {
  }

  public final void onPageScrollStateChanged(int paramInt)
  {
  }

  public final void onPageScrolled(int paramInt1, float paramFloat, int paramInt2)
  {
  }

  public final void onPageSelected(int paramInt)
  {
    ay.a(this.a, paramInt);
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     activity.az
 * JD-Core Version:    0.6.2
 */