package activity;

public final class cx
{
  private String a;
  private int b;

  public final String a()
  {
    return this.a;
  }

  public final void a(int paramInt)
  {
    this.b = paramInt;
  }

  public final void a(String paramString)
  {
    this.a = paramString;
  }

  public final int b()
  {
    return this.b;
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     activity.cx
 * JD-Core Version:    0.6.2
 */