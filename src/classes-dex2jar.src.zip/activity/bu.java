package activity;

import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import com.d.a;

final class bu
  implements CompoundButton.OnCheckedChangeListener
{
  bu(NotifyActivity paramNotifyActivity)
  {
  }

  public final void onCheckedChanged(CompoundButton paramCompoundButton, boolean paramBoolean)
  {
    this.a.h.f(paramBoolean);
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     activity.bu
 * JD-Core Version:    0.6.2
 */