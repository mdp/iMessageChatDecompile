package activity;

public final class l
{
  private String a;
  private String b;
  private String c;
  private boolean d = false;
  private boolean e = false;
  private int f = -1;
  private int g;
  private long h;
  private boolean i = false;
  private int j = 0;
  private int k = 0;

  public l()
  {
  }

  public l(String paramString1, String paramString2, String paramString3, boolean paramBoolean, int paramInt)
  {
    this.a = paramString1;
    this.b = paramString2;
    this.c = paramString3;
    this.d = paramBoolean;
    this.f = paramInt;
    this.g = -1;
  }

  public final String a()
  {
    return this.b;
  }

  public final void a(int paramInt)
  {
    this.f = paramInt;
  }

  public final void a(long paramLong)
  {
    this.h = paramLong;
  }

  public final void a(String paramString)
  {
    this.b = paramString;
  }

  public final String b()
  {
    return this.c;
  }

  public final void b(int paramInt)
  {
    this.j = paramInt;
  }

  public final void b(String paramString)
  {
    this.c = paramString;
  }

  public final void c()
  {
    if (this.e);
    for (boolean bool = false; ; bool = true)
    {
      this.e = bool;
      return;
    }
  }

  public final boolean d()
  {
    return this.e;
  }

  public final int e()
  {
    return this.f;
  }

  public final long f()
  {
    return this.h;
  }

  public final void g()
  {
    this.i = true;
  }

  public final int h()
  {
    return this.j;
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     activity.l
 * JD-Core Version:    0.6.2
 */