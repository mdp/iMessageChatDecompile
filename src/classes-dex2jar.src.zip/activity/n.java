package activity;

import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

final class n
{
  public LinearLayout a;
  public TextView b;
  public ImageView c;
  public ImageView d;
  public int e;
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     activity.n
 * JD-Core Version:    0.6.2
 */