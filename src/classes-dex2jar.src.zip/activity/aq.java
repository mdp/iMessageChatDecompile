package activity;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import com.a.a;

final class aq
  implements DialogInterface.OnClickListener
{
  aq(FriendListActivity paramFriendListActivity, String paramString)
  {
  }

  public final void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    this.a.c.a(this.b);
    this.a.c();
    this.a.b();
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     activity.aq
 * JD-Core Version:    0.6.2
 */