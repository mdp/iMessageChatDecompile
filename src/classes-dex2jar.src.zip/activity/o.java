package activity;

public final class o
{
  private String a;
  private String b;
  private String c;
  private String d;
  private String e;
  private boolean f = true;
  private boolean g = false;
  private boolean h = false;
  private boolean i = false;
  private long j;
  private byte[] k;
  private int l = -1;
  private int m;
  private int n = 0;
  private int o = 0;
  private int p = 0;

  public o()
  {
  }

  public o(String paramString1, String paramString2, String paramString3, boolean paramBoolean, int paramInt)
  {
    this.a = paramString1;
    this.c = paramString2;
    this.d = paramString3;
    this.g = paramBoolean;
    this.l = paramInt;
    this.m = -1;
    this.e = "";
  }

  public final int a()
  {
    return this.p;
  }

  public final void a(int paramInt)
  {
    this.p = paramInt;
  }

  public final void a(long paramLong)
  {
    this.j = paramLong;
  }

  public final void a(String paramString)
  {
    this.a = paramString;
  }

  public final void a(boolean paramBoolean)
  {
    this.i = paramBoolean;
  }

  public final void a(byte[] paramArrayOfByte)
  {
    this.k = paramArrayOfByte;
  }

  public final String b()
  {
    return this.a;
  }

  public final void b(int paramInt)
  {
    this.n = paramInt;
  }

  public final void b(String paramString)
  {
    this.b = paramString;
  }

  public final String c()
  {
    return this.b;
  }

  public final void c(int paramInt)
  {
    this.m = paramInt;
  }

  public final void c(String paramString)
  {
    this.c = paramString;
  }

  public final String d()
  {
    return this.c;
  }

  public final void d(int paramInt)
  {
    this.l = paramInt;
  }

  public final void d(String paramString)
  {
    this.d = paramString;
  }

  public final String e()
  {
    return this.d;
  }

  public final void e(int paramInt)
  {
    this.o = paramInt;
  }

  public final void e(String paramString)
  {
    this.e = paramString;
  }

  public final String f()
  {
    return this.e;
  }

  public final int g()
  {
    return this.n;
  }

  public final void h()
  {
    this.f = false;
  }

  public final boolean i()
  {
    return this.g;
  }

  public final void j()
  {
    this.g = true;
  }

  public final int k()
  {
    return this.m;
  }

  public final int l()
  {
    return this.l;
  }

  public final long m()
  {
    return this.j;
  }

  public final int n()
  {
    return this.o;
  }

  public final byte[] o()
  {
    return this.k;
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     activity.o
 * JD-Core Version:    0.6.2
 */