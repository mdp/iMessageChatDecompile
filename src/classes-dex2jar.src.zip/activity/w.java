package activity;

import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

final class w
{
  public ImageView a;
  public TextView b;
  public TextView c;
  public TextView d;
  public LinearLayout e;
  public int f;
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     activity.w
 * JD-Core Version:    0.6.2
 */