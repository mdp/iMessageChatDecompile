package activity;

import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

final class u
{
  public TextView a;
  public ImageView b;
  public Button c;
  public Button d;
  public boolean e = true;
  public boolean f = false;
  public int g;
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     activity.u
 * JD-Core Version:    0.6.2
 */