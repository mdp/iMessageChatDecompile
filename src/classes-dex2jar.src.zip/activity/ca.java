package activity;

import android.view.View;
import android.view.View.OnClickListener;
import java.util.LinkedList;

final class ca
  implements View.OnClickListener
{
  ca(bx parambx, int paramInt)
  {
  }

  public final void onClick(View paramView)
  {
    if (paramView.getId() == 2131427486)
    {
      bx.e(this.a).remove(this.b);
      e.c.m = "";
      this.a.notifyDataSetChanged();
    }
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     activity.ca
 * JD-Core Version:    0.6.2
 */