package activity;

public final class br
{
  public String a;
  public boolean b;

  public br(NewMessageActivity paramNewMessageActivity)
  {
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     activity.br
 * JD-Core Version:    0.6.2
 */