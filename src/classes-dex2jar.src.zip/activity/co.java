package activity;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

final class co
  implements DialogInterface.OnClickListener
{
  co(RegisterActivity paramRegisterActivity)
  {
  }

  public final void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    this.a.finish();
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     activity.co
 * JD-Core Version:    0.6.2
 */