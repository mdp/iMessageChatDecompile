package activity;

import android.widget.RelativeLayout;
import android.widget.TextView;

final class cw
{
  public RelativeLayout a;
  public TextView b;
  public int c;
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     activity.cw
 * JD-Core Version:    0.6.2
 */