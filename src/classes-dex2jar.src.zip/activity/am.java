package activity;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

final class am
  implements DialogInterface.OnClickListener
{
  am(ai paramai)
  {
  }

  public final void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     activity.am
 * JD-Core Version:    0.6.2
 */