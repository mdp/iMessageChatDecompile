package activity;

import android.view.View;
import android.view.View.OnClickListener;

final class cq
  implements View.OnClickListener
{
  cq(cp paramcp)
  {
  }

  public final void onClick(View paramView)
  {
    this.a.e();
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     activity.cq
 * JD-Core Version:    0.6.2
 */