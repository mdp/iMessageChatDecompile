package activity;

import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;

final class ct
  implements DialogInterface.OnCancelListener
{
  ct(cp paramcp)
  {
  }

  public final void onCancel(DialogInterface paramDialogInterface)
  {
    this.a.d();
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     activity.ct
 * JD-Core Version:    0.6.2
 */