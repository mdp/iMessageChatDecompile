package activity;

public final class aa
{
  public static int a = 0;
  public static int b = 1;
  public static int c = 2;
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     activity.aa
 * JD-Core Version:    0.6.2
 */