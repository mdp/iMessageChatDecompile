package activity;

import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

final class cf
{
  public ImageView a;
  public TextView b;
  public TextView c;
  public TextView d;
  public TextView e;
  public Button f;
  public Button g;
  public TextView h;
  public int i;
  private LinearLayout j;
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     activity.cf
 * JD-Core Version:    0.6.2
 */