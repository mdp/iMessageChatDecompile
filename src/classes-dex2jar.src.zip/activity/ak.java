package activity;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

final class ak
  implements DialogInterface.OnClickListener
{
  ak(ai paramai)
  {
  }

  public final void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     activity.ak
 * JD-Core Version:    0.6.2
 */