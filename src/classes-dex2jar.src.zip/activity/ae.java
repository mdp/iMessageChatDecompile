package activity;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;

final class ae
  implements AdapterView.OnItemClickListener
{
  ae(ac paramac)
  {
  }

  public final void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    this.a.a(ac.c(this.a), 3 * (8 * ac.d(this.a)) + (int)paramLong);
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     activity.ae
 * JD-Core Version:    0.6.2
 */