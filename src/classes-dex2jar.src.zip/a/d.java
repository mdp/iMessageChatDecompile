package a;

import com.c.b;

public final class d
{
  private b a;
  private int b;

  public d(b paramb, int paramInt)
  {
    this.a = paramb;
    this.b = paramInt;
  }

  public final int a()
  {
    return this.b;
  }

  public final b b()
  {
    return this.a;
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     a.d
 * JD-Core Version:    0.6.2
 */