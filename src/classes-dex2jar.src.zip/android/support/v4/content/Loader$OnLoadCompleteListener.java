package android.support.v4.content;

public abstract interface Loader$OnLoadCompleteListener
{
  public abstract void onLoadComplete(Loader paramLoader, Object paramObject);
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.content.Loader.OnLoadCompleteListener
 * JD-Core Version:    0.6.2
 */