package android.support.v4.content;

import android.content.Intent;

class IntentCompat$IntentCompatImplIcsMr1 extends IntentCompat.IntentCompatImplHC
{
  public Intent makeMainSelectorActivity(String paramString1, String paramString2)
  {
    return IntentCompatIcsMr1.makeMainSelectorActivity(paramString1, paramString2);
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.content.IntentCompat.IntentCompatImplIcsMr1
 * JD-Core Version:    0.6.2
 */