package android.support.v4.content;

import java.util.concurrent.Callable;

abstract class ModernAsyncTask$WorkerRunnable
  implements Callable
{
  Object[] mParams;
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.content.ModernAsyncTask.WorkerRunnable
 * JD-Core Version:    0.6.2
 */