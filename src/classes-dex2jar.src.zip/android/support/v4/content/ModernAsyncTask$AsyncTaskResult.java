package android.support.v4.content;

class ModernAsyncTask$AsyncTaskResult
{
  final Object[] mData;
  final ModernAsyncTask mTask;

  ModernAsyncTask$AsyncTaskResult(ModernAsyncTask paramModernAsyncTask, Object[] paramArrayOfObject)
  {
    this.mTask = paramModernAsyncTask;
    this.mData = paramArrayOfObject;
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.content.ModernAsyncTask.AsyncTaskResult
 * JD-Core Version:    0.6.2
 */