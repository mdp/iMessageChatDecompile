package android.support.v4.view;

class ViewPager$3
  implements Runnable
{
  ViewPager$3(ViewPager paramViewPager)
  {
  }

  public void run()
  {
    ViewPager.access$000(this.this$0, 0);
    this.this$0.populate();
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.ViewPager.3
 * JD-Core Version:    0.6.2
 */