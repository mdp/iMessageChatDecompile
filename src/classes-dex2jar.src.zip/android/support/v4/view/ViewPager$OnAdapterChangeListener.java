package android.support.v4.view;

abstract interface ViewPager$OnAdapterChangeListener
{
  public abstract void onAdapterChanged(PagerAdapter paramPagerAdapter1, PagerAdapter paramPagerAdapter2);
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.ViewPager.OnAdapterChangeListener
 * JD-Core Version:    0.6.2
 */