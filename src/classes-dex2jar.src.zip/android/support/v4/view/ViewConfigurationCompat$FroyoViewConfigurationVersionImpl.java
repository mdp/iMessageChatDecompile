package android.support.v4.view;

import android.view.ViewConfiguration;

class ViewConfigurationCompat$FroyoViewConfigurationVersionImpl
  implements ViewConfigurationCompat.ViewConfigurationVersionImpl
{
  public int getScaledPagingTouchSlop(ViewConfiguration paramViewConfiguration)
  {
    return ViewConfigurationCompatFroyo.getScaledPagingTouchSlop(paramViewConfiguration);
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.ViewConfigurationCompat.FroyoViewConfigurationVersionImpl
 * JD-Core Version:    0.6.2
 */