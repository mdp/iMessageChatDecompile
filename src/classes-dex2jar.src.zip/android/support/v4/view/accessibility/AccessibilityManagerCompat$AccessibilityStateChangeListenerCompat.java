package android.support.v4.view.accessibility;

public abstract class AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat
{
  final Object mListener = AccessibilityManagerCompat.access$000().newAccessiblityStateChangeListener(this);

  public abstract void onAccessibilityStateChanged(boolean paramBoolean);
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.accessibility.AccessibilityManagerCompat.AccessibilityStateChangeListenerCompat
 * JD-Core Version:    0.6.2
 */