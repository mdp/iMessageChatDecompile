package android.support.v4.view.accessibility;

class AccessibilityNodeProviderCompat$AccessibilityNodeProviderStubImpl
  implements AccessibilityNodeProviderCompat.AccessibilityNodeProviderImpl
{
  public Object newAccessibilityNodeProviderBridge(AccessibilityNodeProviderCompat paramAccessibilityNodeProviderCompat)
  {
    return null;
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.accessibility.AccessibilityNodeProviderCompat.AccessibilityNodeProviderStubImpl
 * JD-Core Version:    0.6.2
 */