package android.support.v4.view.accessibility;

abstract interface AccessibilityManagerCompatIcs$AccessibilityStateChangeListenerBridge
{
  public abstract void onAccessibilityStateChanged(boolean paramBoolean);
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.accessibility.AccessibilityManagerCompatIcs.AccessibilityStateChangeListenerBridge
 * JD-Core Version:    0.6.2
 */