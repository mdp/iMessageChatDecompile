package android.support.v4.view.accessibility;

import android.view.accessibility.AccessibilityEvent;

class AccessibilityEventCompat$AccessibilityEventStubImpl
  implements AccessibilityEventCompat.AccessibilityEventVersionImpl
{
  public void appendRecord(AccessibilityEvent paramAccessibilityEvent, Object paramObject)
  {
  }

  public Object getRecord(AccessibilityEvent paramAccessibilityEvent, int paramInt)
  {
    return null;
  }

  public int getRecordCount(AccessibilityEvent paramAccessibilityEvent)
  {
    return 0;
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.accessibility.AccessibilityEventCompat.AccessibilityEventStubImpl
 * JD-Core Version:    0.6.2
 */