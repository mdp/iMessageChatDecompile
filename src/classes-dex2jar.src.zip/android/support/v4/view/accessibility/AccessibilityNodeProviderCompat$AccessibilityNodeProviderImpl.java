package android.support.v4.view.accessibility;

abstract interface AccessibilityNodeProviderCompat$AccessibilityNodeProviderImpl
{
  public abstract Object newAccessibilityNodeProviderBridge(AccessibilityNodeProviderCompat paramAccessibilityNodeProviderCompat);
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.accessibility.AccessibilityNodeProviderCompat.AccessibilityNodeProviderImpl
 * JD-Core Version:    0.6.2
 */