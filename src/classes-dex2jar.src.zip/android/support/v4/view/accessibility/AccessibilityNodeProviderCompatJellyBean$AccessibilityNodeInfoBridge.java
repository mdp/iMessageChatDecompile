package android.support.v4.view.accessibility;

import android.os.Bundle;
import java.util.List;

abstract interface AccessibilityNodeProviderCompatJellyBean$AccessibilityNodeInfoBridge
{
  public abstract Object createAccessibilityNodeInfo(int paramInt);

  public abstract List findAccessibilityNodeInfosByText(String paramString, int paramInt);

  public abstract boolean performAction(int paramInt1, int paramInt2, Bundle paramBundle);
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.accessibility.AccessibilityNodeProviderCompatJellyBean.AccessibilityNodeInfoBridge
 * JD-Core Version:    0.6.2
 */