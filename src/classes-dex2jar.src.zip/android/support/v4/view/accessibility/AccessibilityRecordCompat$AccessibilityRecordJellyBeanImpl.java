package android.support.v4.view.accessibility;

import android.view.View;

class AccessibilityRecordCompat$AccessibilityRecordJellyBeanImpl extends AccessibilityRecordCompat.AccessibilityRecordIcsMr1Impl
{
  public void setSource(Object paramObject, View paramView, int paramInt)
  {
    AccessibilityRecordCompatJellyBean.setSource(paramObject, paramView, paramInt);
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.accessibility.AccessibilityRecordCompat.AccessibilityRecordJellyBeanImpl
 * JD-Core Version:    0.6.2
 */