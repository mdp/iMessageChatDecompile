package android.support.v4.view.accessibility;

class AccessibilityRecordCompat$AccessibilityRecordIcsMr1Impl extends AccessibilityRecordCompat.AccessibilityRecordIcsImpl
{
  public int getMaxScrollX(Object paramObject)
  {
    return AccessibilityRecordCompatIcsMr1.getMaxScrollX(paramObject);
  }

  public int getMaxScrollY(Object paramObject)
  {
    return AccessibilityRecordCompatIcsMr1.getMaxScrollY(paramObject);
  }

  public void setMaxScrollX(Object paramObject, int paramInt)
  {
    AccessibilityRecordCompatIcsMr1.setMaxScrollX(paramObject, paramInt);
  }

  public void setMaxScrollY(Object paramObject, int paramInt)
  {
    AccessibilityRecordCompatIcsMr1.setMaxScrollY(paramObject, paramInt);
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.accessibility.AccessibilityRecordCompat.AccessibilityRecordIcsMr1Impl
 * JD-Core Version:    0.6.2
 */