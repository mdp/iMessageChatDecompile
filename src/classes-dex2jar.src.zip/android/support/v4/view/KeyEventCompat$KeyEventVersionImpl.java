package android.support.v4.view;

abstract interface KeyEventCompat$KeyEventVersionImpl
{
  public abstract boolean metaStateHasModifiers(int paramInt1, int paramInt2);

  public abstract boolean metaStateHasNoModifiers(int paramInt);

  public abstract int normalizeMetaState(int paramInt);
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.KeyEventCompat.KeyEventVersionImpl
 * JD-Core Version:    0.6.2
 */