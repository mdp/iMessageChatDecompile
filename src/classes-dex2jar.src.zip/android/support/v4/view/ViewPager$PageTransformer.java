package android.support.v4.view;

import android.view.View;

public abstract interface ViewPager$PageTransformer
{
  public abstract void transformPage(View paramView, float paramFloat);
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.ViewPager.PageTransformer
 * JD-Core Version:    0.6.2
 */