package android.support.v4.view;

class PagerTitleStrip$1
{
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.PagerTitleStrip.1
 * JD-Core Version:    0.6.2
 */