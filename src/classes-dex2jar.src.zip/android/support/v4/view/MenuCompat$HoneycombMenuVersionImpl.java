package android.support.v4.view;

import android.view.MenuItem;

class MenuCompat$HoneycombMenuVersionImpl
  implements MenuCompat.MenuVersionImpl
{
  public boolean setShowAsAction(MenuItem paramMenuItem, int paramInt)
  {
    MenuItemCompatHoneycomb.setShowAsAction(paramMenuItem, paramInt);
    return true;
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.MenuCompat.HoneycombMenuVersionImpl
 * JD-Core Version:    0.6.2
 */