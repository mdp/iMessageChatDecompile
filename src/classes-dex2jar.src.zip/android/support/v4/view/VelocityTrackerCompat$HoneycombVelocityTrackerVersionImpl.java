package android.support.v4.view;

import android.view.VelocityTracker;

class VelocityTrackerCompat$HoneycombVelocityTrackerVersionImpl
  implements VelocityTrackerCompat.VelocityTrackerVersionImpl
{
  public float getXVelocity(VelocityTracker paramVelocityTracker, int paramInt)
  {
    return VelocityTrackerCompatHoneycomb.getXVelocity(paramVelocityTracker, paramInt);
  }

  public float getYVelocity(VelocityTracker paramVelocityTracker, int paramInt)
  {
    return VelocityTrackerCompatHoneycomb.getYVelocity(paramVelocityTracker, paramInt);
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.VelocityTrackerCompat.HoneycombVelocityTrackerVersionImpl
 * JD-Core Version:    0.6.2
 */