package android.support.v4.view;

import android.view.MenuItem;

class MenuCompat$BaseMenuVersionImpl
  implements MenuCompat.MenuVersionImpl
{
  public boolean setShowAsAction(MenuItem paramMenuItem, int paramInt)
  {
    return false;
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.MenuCompat.BaseMenuVersionImpl
 * JD-Core Version:    0.6.2
 */