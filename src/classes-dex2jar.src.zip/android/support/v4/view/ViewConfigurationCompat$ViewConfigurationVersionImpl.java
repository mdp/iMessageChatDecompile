package android.support.v4.view;

import android.view.ViewConfiguration;

abstract interface ViewConfigurationCompat$ViewConfigurationVersionImpl
{
  public abstract int getScaledPagingTouchSlop(ViewConfiguration paramViewConfiguration);
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.ViewConfigurationCompat.ViewConfigurationVersionImpl
 * JD-Core Version:    0.6.2
 */