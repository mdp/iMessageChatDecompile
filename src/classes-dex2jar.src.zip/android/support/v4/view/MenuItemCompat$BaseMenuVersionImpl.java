package android.support.v4.view;

import android.view.MenuItem;
import android.view.View;

class MenuItemCompat$BaseMenuVersionImpl
  implements MenuItemCompat.MenuVersionImpl
{
  public MenuItem setActionView(MenuItem paramMenuItem, View paramView)
  {
    return paramMenuItem;
  }

  public boolean setShowAsAction(MenuItem paramMenuItem, int paramInt)
  {
    return false;
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.MenuItemCompat.BaseMenuVersionImpl
 * JD-Core Version:    0.6.2
 */