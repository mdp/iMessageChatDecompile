package android.support.v4.view;

import android.view.View;

class ViewCompat$JbMr1ViewCompatImpl extends ViewCompat.JBViewCompatImpl
{
  public int getLabelFor(View paramView)
  {
    return ViewCompatJellybeanMr1.getLabelFor(paramView);
  }

  public void setLabelFor(View paramView, int paramInt)
  {
    ViewCompatJellybeanMr1.setLabelFor(paramView, paramInt);
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.ViewCompat.JbMr1ViewCompatImpl
 * JD-Core Version:    0.6.2
 */