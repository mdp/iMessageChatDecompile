package android.support.v4.view;

class ViewPager$ItemInfo
{
  Object object;
  float offset;
  int position;
  boolean scrolling;
  float widthFactor;
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.ViewPager.ItemInfo
 * JD-Core Version:    0.6.2
 */