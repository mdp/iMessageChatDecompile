package android.support.v4.view;

import android.view.MenuItem;

abstract interface MenuCompat$MenuVersionImpl
{
  public abstract boolean setShowAsAction(MenuItem paramMenuItem, int paramInt);
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.MenuCompat.MenuVersionImpl
 * JD-Core Version:    0.6.2
 */