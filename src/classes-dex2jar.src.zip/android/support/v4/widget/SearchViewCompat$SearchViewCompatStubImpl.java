package android.support.v4.widget;

import android.content.ComponentName;
import android.content.Context;
import android.view.View;

class SearchViewCompat$SearchViewCompatStubImpl
  implements SearchViewCompat.SearchViewCompatImpl
{
  public CharSequence getQuery(View paramView)
  {
    return null;
  }

  public boolean isIconified(View paramView)
  {
    return true;
  }

  public boolean isQueryRefinementEnabled(View paramView)
  {
    return false;
  }

  public boolean isSubmitButtonEnabled(View paramView)
  {
    return false;
  }

  public Object newOnCloseListener(SearchViewCompat.OnCloseListenerCompat paramOnCloseListenerCompat)
  {
    return null;
  }

  public Object newOnQueryTextListener(SearchViewCompat.OnQueryTextListenerCompat paramOnQueryTextListenerCompat)
  {
    return null;
  }

  public View newSearchView(Context paramContext)
  {
    return null;
  }

  public void setIconified(View paramView, boolean paramBoolean)
  {
  }

  public void setImeOptions(View paramView, int paramInt)
  {
  }

  public void setInputType(View paramView, int paramInt)
  {
  }

  public void setMaxWidth(View paramView, int paramInt)
  {
  }

  public void setOnCloseListener(Object paramObject1, Object paramObject2)
  {
  }

  public void setOnQueryTextListener(Object paramObject1, Object paramObject2)
  {
  }

  public void setQuery(View paramView, CharSequence paramCharSequence, boolean paramBoolean)
  {
  }

  public void setQueryHint(View paramView, CharSequence paramCharSequence)
  {
  }

  public void setQueryRefinementEnabled(View paramView, boolean paramBoolean)
  {
  }

  public void setSearchableInfo(View paramView, ComponentName paramComponentName)
  {
  }

  public void setSubmitButtonEnabled(View paramView, boolean paramBoolean)
  {
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.widget.SearchViewCompat.SearchViewCompatStubImpl
 * JD-Core Version:    0.6.2
 */