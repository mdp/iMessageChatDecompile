package android.support.v4.widget;

class CursorAdapter$1
{
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.widget.CursorAdapter.1
 * JD-Core Version:    0.6.2
 */