package android.support.v4.widget;

class SearchViewCompat$SearchViewCompatHoneycombImpl$2
  implements SearchViewCompatHoneycomb.OnCloseListenerCompatBridge
{
  SearchViewCompat$SearchViewCompatHoneycombImpl$2(SearchViewCompat.SearchViewCompatHoneycombImpl paramSearchViewCompatHoneycombImpl, SearchViewCompat.OnCloseListenerCompat paramOnCloseListenerCompat)
  {
  }

  public boolean onClose()
  {
    return this.val$listener.onClose();
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.widget.SearchViewCompat.SearchViewCompatHoneycombImpl.2
 * JD-Core Version:    0.6.2
 */