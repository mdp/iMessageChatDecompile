package android.support.v4.widget;

abstract interface SearchViewCompatHoneycomb$OnCloseListenerCompatBridge
{
  public abstract boolean onClose();
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.widget.SearchViewCompatHoneycomb.OnCloseListenerCompatBridge
 * JD-Core Version:    0.6.2
 */