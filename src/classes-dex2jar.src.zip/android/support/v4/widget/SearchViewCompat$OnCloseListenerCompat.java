package android.support.v4.widget;

public abstract class SearchViewCompat$OnCloseListenerCompat
{
  final Object mListener = SearchViewCompat.access$000().newOnCloseListener(this);

  public boolean onClose()
  {
    return false;
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.widget.SearchViewCompat.OnCloseListenerCompat
 * JD-Core Version:    0.6.2
 */