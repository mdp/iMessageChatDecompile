package android.support.v4.widget;

import android.widget.SearchView.OnCloseListener;

final class SearchViewCompatHoneycomb$2
  implements SearchView.OnCloseListener
{
  SearchViewCompatHoneycomb$2(SearchViewCompatHoneycomb.OnCloseListenerCompatBridge paramOnCloseListenerCompatBridge)
  {
  }

  public final boolean onClose()
  {
    return this.val$listener.onClose();
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.widget.SearchViewCompatHoneycomb.2
 * JD-Core Version:    0.6.2
 */