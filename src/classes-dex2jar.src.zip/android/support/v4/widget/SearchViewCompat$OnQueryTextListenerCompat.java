package android.support.v4.widget;

public abstract class SearchViewCompat$OnQueryTextListenerCompat
{
  final Object mListener = SearchViewCompat.access$000().newOnQueryTextListener(this);

  public boolean onQueryTextChange(String paramString)
  {
    return false;
  }

  public boolean onQueryTextSubmit(String paramString)
  {
    return false;
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.widget.SearchViewCompat.OnQueryTextListenerCompat
 * JD-Core Version:    0.6.2
 */