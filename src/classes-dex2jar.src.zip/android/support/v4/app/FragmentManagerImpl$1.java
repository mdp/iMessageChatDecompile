package android.support.v4.app;

class FragmentManagerImpl$1
  implements Runnable
{
  FragmentManagerImpl$1(FragmentManagerImpl paramFragmentManagerImpl)
  {
  }

  public void run()
  {
    this.this$0.execPendingActions();
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.FragmentManagerImpl.1
 * JD-Core Version:    0.6.2
 */