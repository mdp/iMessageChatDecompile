package android.support.v4.app;

import android.view.View;

class FragmentActivity$2
  implements FragmentContainer
{
  FragmentActivity$2(FragmentActivity paramFragmentActivity)
  {
  }

  public View findViewById(int paramInt)
  {
    return this.this$0.findViewById(paramInt);
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.FragmentActivity.2
 * JD-Core Version:    0.6.2
 */