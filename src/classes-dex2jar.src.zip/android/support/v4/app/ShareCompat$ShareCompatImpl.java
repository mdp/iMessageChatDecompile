package android.support.v4.app;

import android.view.MenuItem;

abstract interface ShareCompat$ShareCompatImpl
{
  public abstract void configureMenuItem(MenuItem paramMenuItem, ShareCompat.IntentBuilder paramIntentBuilder);

  public abstract String escapeHtml(CharSequence paramCharSequence);
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.ShareCompat.ShareCompatImpl
 * JD-Core Version:    0.6.2
 */