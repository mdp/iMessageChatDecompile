package android.support.v4.app;

import java.util.ArrayList;
import java.util.HashMap;

final class FragmentActivity$NonConfigurationInstances
{
  Object activity;
  HashMap children;
  Object custom;
  ArrayList fragments;
  HashMap loaders;
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.FragmentActivity.NonConfigurationInstances
 * JD-Core Version:    0.6.2
 */