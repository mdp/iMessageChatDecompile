package android.support.v4.app;

import android.app.Notification;

abstract interface NotificationCompat$NotificationCompatImpl
{
  public abstract Notification build(NotificationCompat.Builder paramBuilder);
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.NotificationCompat.NotificationCompatImpl
 * JD-Core Version:    0.6.2
 */