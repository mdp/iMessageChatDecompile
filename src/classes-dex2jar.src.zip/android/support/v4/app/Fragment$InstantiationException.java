package android.support.v4.app;

public class Fragment$InstantiationException extends RuntimeException
{
  public Fragment$InstantiationException(String paramString, Exception paramException)
  {
    super(paramString, paramException);
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.Fragment.InstantiationException
 * JD-Core Version:    0.6.2
 */