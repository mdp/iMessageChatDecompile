package android.support.v4.app;

class FragmentActivity$FragmentTag
{
  public static final int[] Fragment = { 16842755, 16842960, 16842961 };
  public static final int Fragment_id = 1;
  public static final int Fragment_name = 0;
  public static final int Fragment_tag = 2;
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.FragmentActivity.FragmentTag
 * JD-Core Version:    0.6.2
 */