package android.support.v4.app;

import android.os.Parcel;
import android.os.Parcelable.Creator;

final class Fragment$SavedState$1
  implements Parcelable.Creator
{
  public final Fragment.SavedState createFromParcel(Parcel paramParcel)
  {
    return new Fragment.SavedState(paramParcel, null);
  }

  public final Fragment.SavedState[] newArray(int paramInt)
  {
    return new Fragment.SavedState[paramInt];
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.Fragment.SavedState.1
 * JD-Core Version:    0.6.2
 */