package android.support.v4.app;

import android.os.Bundle;

final class FragmentTabHost$TabInfo
{
  private final Bundle args;
  private final Class clss;
  private Fragment fragment;
  private final String tag;

  FragmentTabHost$TabInfo(String paramString, Class paramClass, Bundle paramBundle)
  {
    this.tag = paramString;
    this.clss = paramClass;
    this.args = paramBundle;
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.FragmentTabHost.TabInfo
 * JD-Core Version:    0.6.2
 */