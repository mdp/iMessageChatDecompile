package android.support.v4.app;

public abstract interface FragmentManager$OnBackStackChangedListener
{
  public abstract void onBackStackChanged();
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.FragmentManager.OnBackStackChangedListener
 * JD-Core Version:    0.6.2
 */