package android.support.v4.app;

import java.util.ArrayList;

final class BackStackRecord$Op
{
  int cmd;
  int enterAnim;
  int exitAnim;
  Fragment fragment;
  Op next;
  int popEnterAnim;
  int popExitAnim;
  Op prev;
  ArrayList removed;
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.BackStackRecord.Op
 * JD-Core Version:    0.6.2
 */