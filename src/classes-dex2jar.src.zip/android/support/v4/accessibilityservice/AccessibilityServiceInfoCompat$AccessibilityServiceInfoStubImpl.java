package android.support.v4.accessibilityservice;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.pm.ResolveInfo;

class AccessibilityServiceInfoCompat$AccessibilityServiceInfoStubImpl
  implements AccessibilityServiceInfoCompat.AccessibilityServiceInfoVersionImpl
{
  public boolean getCanRetrieveWindowContent(AccessibilityServiceInfo paramAccessibilityServiceInfo)
  {
    return false;
  }

  public String getDescription(AccessibilityServiceInfo paramAccessibilityServiceInfo)
  {
    return null;
  }

  public String getId(AccessibilityServiceInfo paramAccessibilityServiceInfo)
  {
    return null;
  }

  public ResolveInfo getResolveInfo(AccessibilityServiceInfo paramAccessibilityServiceInfo)
  {
    return null;
  }

  public String getSettingsActivityName(AccessibilityServiceInfo paramAccessibilityServiceInfo)
  {
    return null;
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.accessibilityservice.AccessibilityServiceInfoCompat.AccessibilityServiceInfoStubImpl
 * JD-Core Version:    0.6.2
 */