package android.support.v4.net;

import android.net.ConnectivityManager;

abstract interface ConnectivityManagerCompat$ConnectivityManagerCompatImpl
{
  public abstract boolean isActiveNetworkMetered(ConnectivityManager paramConnectivityManager);
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.net.ConnectivityManagerCompat.ConnectivityManagerCompatImpl
 * JD-Core Version:    0.6.2
 */