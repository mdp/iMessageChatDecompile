package android.support.v4.net;

class TrafficStatsCompat$BaseTrafficStatsCompatImpl$1 extends ThreadLocal
{
  TrafficStatsCompat$BaseTrafficStatsCompatImpl$1(TrafficStatsCompat.BaseTrafficStatsCompatImpl paramBaseTrafficStatsCompatImpl)
  {
  }

  protected TrafficStatsCompat.BaseTrafficStatsCompatImpl.SocketTags initialValue()
  {
    return new TrafficStatsCompat.BaseTrafficStatsCompatImpl.SocketTags(null);
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.net.TrafficStatsCompat.BaseTrafficStatsCompatImpl.1
 * JD-Core Version:    0.6.2
 */