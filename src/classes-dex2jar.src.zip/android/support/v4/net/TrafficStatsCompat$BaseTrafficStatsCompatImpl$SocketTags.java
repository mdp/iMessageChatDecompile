package android.support.v4.net;

class TrafficStatsCompat$BaseTrafficStatsCompatImpl$SocketTags
{
  public int statsTag = -1;
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.net.TrafficStatsCompat.BaseTrafficStatsCompatImpl.SocketTags
 * JD-Core Version:    0.6.2
 */