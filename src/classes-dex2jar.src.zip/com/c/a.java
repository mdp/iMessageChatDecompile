package com.c;

public final class a
{
  public static String a;
  public static String b;
  public static boolean c = false;
  public static int d = -1;
  public static String e;
  public static String f;
  public static int g = 0;
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     com.c.a
 * JD-Core Version:    0.6.2
 */