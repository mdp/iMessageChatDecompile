package com.c;

public final class h
{
  public static float a;
  public static float b;

  public static float a()
  {
    return 250.0F * a / 480.0F;
  }

  public static float b()
  {
    return 270.0F * a / 480.0F;
  }

  public static float c()
  {
    return 250.0F * a / 480.0F;
  }

  public static float d()
  {
    return 45.0F * b / 854.0F;
  }

  public static float e()
  {
    return 45.0F * b / 854.0F;
  }

  public static float f()
  {
    return 50.0F * a / 480.0F;
  }

  public static float g()
  {
    return 32.0F * a / 480.0F;
  }

  public static float h()
  {
    return 20.0F * a / 480.0F;
  }

  public static float i()
  {
    return 200.0F * a / 480.0F;
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     com.c.h
 * JD-Core Version:    0.6.2
 */