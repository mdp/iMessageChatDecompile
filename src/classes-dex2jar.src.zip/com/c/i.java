package com.c;

import java.util.ArrayList;

public final class i
{
  public ArrayList a;
  public ArrayList b;
  public ArrayList c;
  public int d;
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     com.c.i
 * JD-Core Version:    0.6.2
 */