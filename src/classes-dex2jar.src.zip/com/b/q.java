package com.b;

import com.c.j;

public abstract interface q
{
  public abstract void a(j paramj);
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     com.b.q
 * JD-Core Version:    0.6.2
 */