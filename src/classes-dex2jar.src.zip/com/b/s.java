package com.b;

import com.c.b;

public final class s
{
  public static b a(long paramLong)
  {
    byte[] arrayOfByte = new byte[14];
    arrayOfByte[0] = 5;
    arrayOfByte[1] = 0;
    arrayOfByte[2] = 0;
    arrayOfByte[3] = 0;
    arrayOfByte[4] = 8;
    arrayOfByte[5] = 4;
    arrayOfByte[6] = 1;
    arrayOfByte[7] = 2;
    arrayOfByte[8] = 0;
    arrayOfByte[9] = 4;
    arrayOfByte[10] = ((byte)(int)(paramLong >> 24));
    arrayOfByte[11] = ((byte)(int)(paramLong >> 16));
    arrayOfByte[12] = ((byte)(int)(paramLong >> 8));
    arrayOfByte[13] = ((byte)(int)(paramLong >> 0));
    return new b(arrayOfByte, 14);
  }

  public static b b(long paramLong)
  {
    byte[] arrayOfByte = new byte[14];
    arrayOfByte[0] = 5;
    arrayOfByte[1] = 0;
    arrayOfByte[2] = 0;
    arrayOfByte[3] = 0;
    arrayOfByte[4] = 8;
    arrayOfByte[5] = 4;
    arrayOfByte[6] = 2;
    arrayOfByte[7] = 2;
    arrayOfByte[8] = 0;
    arrayOfByte[9] = 4;
    arrayOfByte[10] = ((byte)(int)(paramLong >> 24));
    arrayOfByte[11] = ((byte)(int)(paramLong >> 16));
    arrayOfByte[12] = ((byte)(int)(paramLong >> 8));
    arrayOfByte[13] = ((byte)(int)(paramLong >> 0));
    return new b(arrayOfByte, 14);
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     com.b.s
 * JD-Core Version:    0.6.2
 */