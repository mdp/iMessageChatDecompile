package com.b;

public abstract interface r
{
  public abstract void a(int paramInt1, int paramInt2, float paramFloat);
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     com.b.r
 * JD-Core Version:    0.6.2
 */