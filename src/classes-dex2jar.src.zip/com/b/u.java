package com.b;

public final class u
{
  private String a;

  public u(String paramString)
  {
    this.a = paramString;
  }
}

/* Location:           /Users/mdp/Downloads/iMessage/classes-dex2jar.jar
 * Qualified Name:     com.b.u
 * JD-Core Version:    0.6.2
 */